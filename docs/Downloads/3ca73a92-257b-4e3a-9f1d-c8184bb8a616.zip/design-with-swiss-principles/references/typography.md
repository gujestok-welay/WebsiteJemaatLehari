# Typography

Use typography as the primary carrier of content, structure, rhythm, and tone. Choose type for the reading task and production context, not because it resembles a historical Swiss poster.

## Choose type

Prefer typefaces with:

- clear forms at the required sizes;
- sufficient weights and styles for the hierarchy;
- suitable numerals, symbols, language coverage, and technical features;
- reliable rendering and licensing in the target medium;
- a tone appropriate to the content and brand.

A neutral sans serif is common, not mandatory. Use serif, monospace, variable, or mixed systems when they better serve reading, data, code, voice, or context.

## Build the system

1. Define body text first for sustained legibility.
2. Create a restrained type scale from semantic roles.
3. Use weight, size, spacing, and position before adding colour or ornament.
4. Set line height and measure for the medium and density.
5. Define label, caption, metadata, link, code, numeric, and interactive states.
6. Use consistent casing, punctuation, alignment, and wrapping rules.

Avoid unnecessary font families, weights, sizes, all-caps treatments, and arbitrary letter spacing. Do not use light weights for small text or low contrast to signal sophistication.

## Typesetting guidance

- Use sentence case by default for readability; depart when brand or convention requires it.
- Keep prose lines roughly 45–75 characters where possible.
- Increase line height for longer measures, small text, or dense prose.
- Use tabular numerals for columns of changing or comparable values.
- Align numbers according to the comparison users need to make.
- Prevent isolated headings, awkward wraps, and ambiguous labels.
- Use underlines or other conventional cues for links where context does not make them obvious.

## Test

Read the artifact without colour, imagery, containers, or icons. Its structure should remain intelligible through type and spacing. Check legibility at the smallest intended size, under zoom, and across likely devices or export formats.
