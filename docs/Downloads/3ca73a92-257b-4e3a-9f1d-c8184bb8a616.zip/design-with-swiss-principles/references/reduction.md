# Reduction

Reduction removes interference so that content, relationships, and actions become easier to understand. It is not visual emptiness.

## Apply reduction

1. Identify the artifact's primary task or message.
2. Classify each element as essential, supportive, contextual, redundant, or decorative.
3. Remove redundant elements.
4. Consolidate repeated controls, labels, styles, or messages.
5. Subordinate supporting and contextual material instead of deleting necessary context.
6. Recheck orientation, usability, trust, and accessibility after each pass.

## Prefer

- one clear action over several competing calls to action;
- direct labels over icon-only controls;
- grouping over repeated boxes and borders;
- whitespace over decorative separators;
- a small set of reusable patterns over local variations;
- concise language over compressed or cryptic language;
- progressive disclosure when complexity is real but not always needed.

## Preserve

Do not remove:

- information required for informed decisions;
- labels, units, legends, sources, uncertainty, or qualifications;
- focus states, error guidance, accessible names, or alternative representations;
- cues needed to understand interaction or navigation;
- meaningful brand or cultural context merely because it is expressive.

## Test

For each element, ask:

- What job does this perform?
- Is that job necessary here?
- Could content, type, spacing, or alignment perform it more simply?
- Would a first-time user notice its absence?
- Would removing it make the artifact less honest, accessible, or usable?

If an element has no defensible job, remove it. If the underlying need is real, solve it with the least intrusive device that works.
