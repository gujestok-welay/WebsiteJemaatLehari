# Grid

A grid is a system of spatial relationships. Use it to make alignment, grouping, sequence, and comparison predictable. Do not treat it as a decorative overlay or an inflexible template.

## Construct the grid

1. Start from content types and reading behaviour.
2. Define the usable field, margins, columns, gutters, and vertical rhythm.
3. Choose a spacing unit appropriate to the medium.
4. Map major content roles to spans and alignment lines.
5. Define how the grid reflows, collapses, or changes across formats.
6. Document deliberate exceptions.

## Practical defaults

Use defaults only as starting points:

- base spacing unit: 4 or 8 px for interfaces;
- compact interface grids: 4 columns on narrow screens, 8 on medium screens, and 12 on wide screens;
- readable prose measure: roughly 45–75 characters per line;
- tabular numbers: align decimals or digits consistently;
- vertical rhythm: derive spacing from a limited scale rather than isolated values.

Adapt column count, measure, margins, and density to the content. A dashboard, report, mobile form, slide, and poster require different grids.

## Use alignment to encode meaning

- Align related labels, values, controls, and headings.
- Use proximity and shared edges before containers.
- Keep repeated structures dimensionally consistent.
- Align text by meaningful baselines or edges.
- Allow whitespace to form groups and intervals.
- Break the grid only to create a justified focal point or accommodate a genuine content need.

## Responsive behaviour

Specify what remains fixed, what becomes fluid, what wraps, what stacks, what scrolls, and what is progressively disclosed. Preserve semantic order when visual columns collapse. Avoid shrinking content until it merely fits.

## Test

Hide decoration and colour. The structure should remain visible through position, spacing, and alignment. Check that exceptions appear intentional and that the grid supports rather than constrains comprehension.
