# Hierarchy

Hierarchy controls attention and reveals reading order. Build it from content importance, not from arbitrary stylistic variety.

## Establish hierarchy

1. Rank content by user need and task sequence.
2. Assign a small number of semantic levels.
3. Encode each level consistently through position, scale, weight, spacing, and density.
4. Reserve strong contrast for genuinely important content or actions.
5. Reduce emphasis on secondary material without making it illegible.

## Use contrast deliberately

Prefer a few meaningful contrasts:

- larger versus smaller;
- heavier versus regular;
- near versus separated;
- aligned versus deliberately offset;
- dense versus open;
- primary text versus muted supporting text.

Do not combine every contrast at once. Size, weight, colour, boxes, icons, and position all shouting together create noise rather than hierarchy.

## Sequence attention

Support three levels of reading:

1. immediate orientation: what this is and what matters now;
2. scanning: major sections, values, choices, or findings;
3. close reading: details, explanations, evidence, and metadata.

For task interfaces, order hierarchy around the next useful action. For documentation, order it around the argument. For data displays, order it around the comparison or finding.

## Test

- Squint or view the artifact at reduced size. The major levels should remain apparent.
- Convert it to grayscale. The reading order should survive.
- Scan only headings, labels, and actions. They should form a coherent outline.
- Count competing focal points. If several demand attention at once, reduce contrast.
- Check that visual importance matches semantic importance.
