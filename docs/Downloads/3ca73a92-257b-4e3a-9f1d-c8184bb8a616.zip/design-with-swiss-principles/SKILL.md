---
name: design-with-swiss-principles
description: Create, critique, revise, specify, or implement information-rich visual work when the user explicitly asks for Swiss or International Typographic Style, Swiss-informed design, or grid-led structural simplification. Apply reduction, grid, hierarchy, and typography without overriding brand, accessibility, medium, or technical constraints. Do not activate merely because a design task involves clarity, typography, alignment, or visual hierarchy.
_agensi: "bb349ce7-0a29-47ec-a336-6fde26342877"
---

# Design with Swiss Principles

Use Swiss design as a discipline for comprehension, not as a period costume. Create one strong primary direction. Offer alternatives only when the brief contains a meaningful unresolved choice.

## Governing principle

Pursue clarity through reduction. Require every element to serve comprehension, navigation, comparison, emphasis, trust, or action. Remove it otherwise. Stop removing when further reduction would damage meaning, usability, accessibility, orientation, or necessary character.

Treat brand requirements, accessibility needs, content integrity, user needs, medium, and technical constraints as fixed unless the user permits changes. If a requested treatment conflicts with comprehension, identify the conflict directly and recommend a clearer alternative.

## Select the mode

Choose the mode implied by the request. Combine modes when useful.

- **Create:** Develop a resolved visual direction from a brief or source material.
- **Critique:** Diagnose problems, explain their effect, and prioritise changes.
- **Revise:** Preserve what works, correct structural weaknesses, and show material changes.
- **Specify:** Produce a build-ready system of layout, type, spacing, colour, components, and responsive behaviour.
- **Implement:** Apply the direction in the requested tool or medium and verify the result.

Remain tool-agnostic until the user names a medium or implementation environment. Then adapt to its capabilities and conventions rather than forcing a print-poster grammar onto it.

## Work in five stages

### 1. Establish the brief

Determine:

- audience, task, context, and desired action;
- content types, density, and importance;
- medium, format, viewport, and delivery constraints;
- brand, accessibility, localisation, and technical requirements;
- what is fixed, negotiable, or missing.

Inspect supplied content or existing work before redesigning it. Ask only when missing information would materially change the result. Otherwise state compact assumptions and proceed.

### 2. Find the information structure

Reduce the material to its semantic roles before styling it:

- primary message or task;
- supporting information;
- navigation and orientation;
- evidence, metadata, labels, and controls;
- required actions or decisions.

Group related elements, separate unlike elements, and establish a deliberate reading order. Do not solve an information-architecture problem with styling alone.

### 3. Build the system

Apply the four principles in this order:

1. **Reduction:** Remove, consolidate, or subordinate noise. Read [references/reduction.md](references/reduction.md).
2. **Grid:** Define consistent spatial relationships. Read [references/grid.md](references/grid.md).
3. **Hierarchy:** Encode reading order and importance. Read [references/hierarchy.md](references/hierarchy.md).
4. **Typography:** Make type carry structure and tone. Read [references/typography.md](references/typography.md).

Use colour, rules, imagery, icons, motion, shadows, and other treatments only where they add meaning, state, orientation, affordance, or necessary brand expression. Make the design understandable in grayscale unless colour itself conveys data; never use colour as the sole carrier of meaning.

### 4. Produce the requested output

Match the output to the task:

- **Concept:** State the organising idea, content logic, grid, type system, palette, and key decisions.
- **Critique:** Lead with the most consequential issue. Separate structural problems from preferences. Rank recommendations by impact.
- **Revision:** Provide the revised artifact or precise changes, not critique alone.
- **Specification:** Give measurable values, tokens, states, breakpoints, exceptions, and content rules sufficient for another person to build.
- **Implementation:** Produce the artifact or code, follow the established environment, and test the actual result where possible.

Do not decorate a weak structure. Resolve content, sequence, alignment, and typographic contrast first.

### 5. Run the Swiss test

Before finalising, check:

1. **Reduction:** Can anything be removed without losing meaning or function?
2. **Grid:** Do alignment and spacing reveal relationships and create rhythm?
3. **Hierarchy:** Is the intended reading order immediately apparent?
4. **Typography:** Is type doing most of the structural work?
5. **Adaptation:** Does the solution respect its audience, medium, brand, accessibility, and technical context?

Revise when any answer is no. Report important trade-offs rather than pretending they do not exist.

### Verify implemented work

When producing an artifact or code, verify the actual output rather than only the design rationale:

- render, open, or inspect the artifact in its target medium when the capability is available;
- run relevant existing project checks and test primary interactions and states;
- check responsive or reflow behaviour, keyboard and focus behaviour, contrast and colour independence, legibility, and export integrity when applicable;
- correct observed defects or report them plainly; and
- state what could not be tested.

Do not claim that an implementation is verified without observed results.

## Medium-specific guidance

### Interfaces

Prioritise task flow, clear states, predictable alignment, keyboard and screen-reader usability, legible targets, responsive reflow, and restrained component variation. Let interaction conventions override stylistic purity where needed.

### Data visualisations

Choose the simplest encoding that answers the question. Remove chart furniture before removing useful context. Preserve labels, units, baselines, uncertainty, source notes, and accessible alternatives. Use alignment and typography to make comparison easier.

### Documentation and prose

Design the information architecture as carefully as the page. Use headings, summaries, lists, tables, examples, whitespace, and metadata to support scanning without fragmenting the argument. Keep line length and paragraph rhythm readable.

### CLI and terminal output

Use stable columns, restrained emphasis, short labels, meaningful whitespace, and text symbols that survive monochrome and narrow widths. Do not depend on colour or decorative box drawing for comprehension.

## Guard against common failures

- **Decoration creep:** Require a functional reason for gradients, shadows, illustrations, icons, rules, and motion.
- **Hierarchy collapse:** Limit the number of type sizes, weights, colours, and emphasis patterns.
- **Grid abandonment:** Treat exceptions as deliberate, documented decisions rather than local convenience.
- **Colour as a crutch:** Establish hierarchy through content, position, spacing, size, and weight first.
- **False minimalism:** Do not remove labels, context, affordances, evidence, or accessibility support to make an artifact look cleaner.
- **Swiss imitation:** Avoid defaulting to red, black, Helvetica, asymmetry, lowercase headings, or poster-like composition without a contextual reason.
- **Generic sterility:** Preserve relevant voice and character through proportion, typography, imagery, language, and controlled exceptions.

## Response standard

Lead with the resolved direction or the most important diagnosis. Explain decisions in terms of comprehension and use, not taste. Make recommendations concrete enough to act on. Avoid presenting multiple superficial variations as choice.
